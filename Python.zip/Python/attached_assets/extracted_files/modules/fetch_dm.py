def fetch_dms(session_file):
    # Mock response
    return [{"user": "ex_boy", "last_message": "miss u"}]
