# Sugarglitch Toolkit: Replit Edition

## ใช้งานอย่างไร
1. ใส่ sessionid ลงใน `session.json`
2. รันผ่าน Replit หรือ VPS โดยสั่ง `python3 main.py`
3. ไฟล์รายงานจะถูกสร้างไว้ในโฟลเดอร์ `export/`
4. เชื่อม webhook ได้ใน `webhook/discord_notify.py`

## ตั้งเวลา Auto Run บน Replit
ใช้ Scheduled Deployment ตั้งให้รันทุกวันตอน 7AM (Bangkok)
